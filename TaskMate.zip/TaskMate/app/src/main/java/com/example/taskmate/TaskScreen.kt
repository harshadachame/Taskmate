package com.example.taskmate

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.example.taskmate.ui.theme.TaskMateTheme
import com.google.accompanist.navigation.animation.AnimatedNavHost
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.rpc.context.AttributeContext.Auth

class TaskScreen : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this) ?: throw IllegalStateException("FirebaseApp is null!")
            Log.d("Firebase", "Firebase initialized successfully!")
        } catch (e: Exception) {
            Log.e("Firebase", "Firebase initialization failed: ${e.message}")
        }

        // enableEdgeToEdge()
        setContent {
            MainScreen()
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainScreen() {
    Log.d("MainScreen", "MainScreen is being called")
    val navController = rememberNavController()

    val context = LocalContext.current
    val database = remember { TaskDatabase.getInstance(context) }
    val repository = remember { TaskRepository(database.taskDao()) }
    val viewModel = remember { TaskViewModel(repository) }

    val auth = remember { FirebaseAuth.getInstance() }
    var isUserChecked by remember { mutableStateOf(false) }
    var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            isLoggedIn = firebaseAuth.currentUser != null
            isUserChecked = true
        }
        auth.addAuthStateListener(listener)

        isUserChecked = true  // Ensure UI updates even if listener is slow

        onDispose {
            auth.removeAuthStateListener(listener)
        }
    }

    if (!isUserChecked) {
        LoadingScreen()
    } else {
        TaskMateTheme {
            val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

            val showBottomBar = currentRoute !in listOf("login", "register")  // Hide Bottom Bar on Login/Register

            Scaffold(
                bottomBar = { if (showBottomBar) BottomNavigationBar(navController) } // Conditionally show Bottom Bar
            ) { paddingValues ->
                val startDestination = if (isLoggedIn) "home" else "login"
                AnimatedNavHost(
                    navController = navController,
                    startDestination = startDestination,
                    modifier = Modifier.padding(paddingValues),
                    enterTransition = { fadeIn(animationSpec = tween(500)) },
                    exitTransition = { fadeOut(animationSpec = tween(500)) }
                ) {
                    composable("login") { LoginScreen(navController, auth) }
                    composable("register") { RegisterScreen(navController, auth) }
                    composable("home") { TaskListScreen(navController, viewModel) }
                    composable("profile") { ProfileScreen(navController) }
                    composable("other") { OtherScreen() }
                    composable("addTask") { AddTaskScreen(navController, viewModel) }
                    composable("dashboard") { DashboardScreen(viewModel) }
                    composable("editTask/{taskId}") { backStackEntry ->
                        val taskId = backStackEntry.arguments?.getInt("taskId") ?: -1
                        EditTaskScreen(navController, viewModel, taskId)
                    }
                }
            }
        }
    }
}

@Composable
fun LoadingScreen() {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        CircularProgressIndicator()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, auth: FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isPasswordVisible by remember { mutableStateOf(false) }

    val isEmailValid = Patterns.EMAIL_ADDRESS.matcher(email).matches()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1,
                isError = !isEmailValid && email.isNotEmpty()
            )
            if (!isEmailValid && email.isNotEmpty()) {
                Text("Invalid email format", color = Color.Red, fontSize = 12.sp)
            }

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1,
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            errorMessage?.let {
                Text(it, color = Color.Red, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                CircularProgressIndicator()
            } else {
                Button(
                    onClick = {
                        if (!isEmailValid) {
                            errorMessage = "Please enter a valid email"
                            return@Button
                        }

                        isLoading = true
                        auth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                isLoading = false
                                if (task.isSuccessful) {
                                    navController.navigate("home") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                } else {
                                    val errorCode = task.exception?.message ?: "Login failed"
                                    errorMessage = when {
                                        errorCode.contains("password is invalid", ignoreCase = true) -> "Wrong password entered"
                                        errorCode.contains("no user record", ignoreCase = true) -> "Email not registered"
                                        else -> "Login failed. Please check your details"
                                    }
                                }
                            }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = isEmailValid
                ) {
                    Text("Login")
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = { navController.navigate("register") }) {
                    Text("Don't have an account? Register")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(navController: NavController, auth: FirebaseAuth) {
    var name by remember { mutableStateOf("") }
    var surname by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isPasswordVisible by remember { mutableStateOf(false) }

    val isEmailValid = Patterns.EMAIL_ADDRESS.matcher(email).matches()
    val isPasswordValid = password.length >= 6 &&
            password.any { it.isDigit() } &&
            password.any { it.isUpperCase() } &&
            password.any { "!@#$%^&*()_+-=[]{}|;:'\",.<>?/".contains(it) }
    val isConfirmPasswordValid = confirmPassword == password

    val db = remember { FirebaseFirestore.getInstance() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("First Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1
            )

            OutlinedTextField(
                value = surname,
                onValueChange = { surname = it },
                label = { Text("Surname") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1,
                isError = !isEmailValid && email.isNotEmpty()
            )

            if (!isEmailValid && email.isNotEmpty()) {
                Text("Invalid email format", color = Color.Red, fontSize = 12.sp)
            }

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1,
                isError = !isPasswordValid && password.isNotEmpty(),
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                }
            )

            if (!isPasswordValid && password.isNotEmpty()) {
                Text(
                    "Password must be at least 6 chars, 1 digit, 1 uppercase, 1 special character",
                    color = Color.Red,
                    fontSize = 12.sp
                )
            }

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm Password") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                maxLines = 1,
                isError = !isConfirmPasswordValid && confirmPassword.isNotEmpty(),
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                }
            )

            if (!isConfirmPasswordValid && confirmPassword.isNotEmpty()) {
                Text("Passwords do not match", color = Color.Red, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                CircularProgressIndicator()
            }  else {
                Button(
                    onClick = {
                        if (password != confirmPassword) {
                            errorMessage = "Passwords do not match"
                            return@Button
                        }

                        isLoading = true
                        auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val user = auth.currentUser
                                    val userData = hashMapOf(
                                        "uid" to user?.uid,
                                        "name" to name,
                                        "surname" to surname,
                                        "email" to email
                                    )

                                    // Save user data in Firestore
                                    db.collection("users").document(user!!.uid).set(userData)
                                        .addOnSuccessListener {
                                            isLoading = false
                                            navController.navigate("home") {
                                                popUpTo("register") { inclusive = true }
                                            }
                                        }
                                        .addOnFailureListener {
                                            isLoading = false
                                            errorMessage = "Failed to save user data"
                                        }
                                } else {
                                    isLoading = false
                                    errorMessage = task.exception?.localizedMessage ?: "Registration failed"
                                }
                            }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = isEmailValid && isPasswordValid && isConfirmPasswordValid
                ) {
                    Text("Register")
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = { navController.navigate("login") }) {
                    Text("Already have an account? Login")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskListScreen(navController: NavController, viewModel: TaskViewModel) {
    val tasks by viewModel.allTasks.collectAsState()
    val filterStatus by viewModel.filterStatus.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("addTask") }) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // **Filtering & Sorting Row**
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // **Filter Dropdown**
                DropdownMenuBox(
                    label = "Filter",
                    selectedOption = filterStatus,
                    options = listOf("All", "Completed", "Pending"),
                    onOptionSelected = { viewModel.setFilterStatus(it) }
                )

                // **Sort Dropdown**
                DropdownMenuBox(
                    label = "Sort",
                    selectedOption = sortOption,
                    options = listOf("Due Date", "Name"),
                    onOptionSelected = { viewModel.setSortOption(it) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // **Task List**
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(tasks) { task ->
                    TaskItem(
                        task = task,
                        onTaskClick = { navController.navigate("editTask/${task.id}") },
                        onTaskCompleted = {
                            val updatedTask = task.copy(isCompleted = !task.isCompleted)
                            viewModel.updateTask(updatedTask)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DropdownMenuBox(
    label: String,
    selectedOption: String,
    options: List<String>,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        Text(text = label, fontWeight = FontWeight.Bold)

        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(selectedOption)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = {
                        onOptionSelected(option)
                        expanded = false
                    })
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    val items = listOf(
        BottomNavItem("home", Icons.Default.Home, "Home"),
        BottomNavItem("profile", Icons.Default.Person, "Profile"),
        BottomNavItem("other", Icons.Default.Settings, "Other"),
        BottomNavItem("dashboard", Icons.Default.Dashboard, "Dashboard")
    )

    NavigationBar {
        val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

        items.forEach { item ->
            val isSelected = currentRoute == item.route

            // 🔥 Scale animation for icon
            val scale by animateFloatAsState(
                targetValue = if (isSelected) 1.5f else 1f, // Enlarge selected icon
                animationSpec = tween(durationMillis = 300), label = ""
            )

            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        modifier = Modifier.scale(scale) // ✅ Apply scale animation
                    )
                },
                label = { Text(item.label) },
                selected = isSelected,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Blue,
                    unselectedIconColor = Color.Gray,
                    selectedTextColor = Color.Blue,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}

data class BottomNavItem(val route: String, val icon: ImageVector, val label: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {
    val user = FirebaseAuth.getInstance().currentUser
    val db = FirebaseFirestore.getInstance()
    val userName = remember { mutableStateOf("Guest") }
    val userEmail = remember { mutableStateOf("Not Logged In") }
    val userPhotoUrl = remember { mutableStateOf<String?>(null) }

    // Fetch user details from Firestore
    LaunchedEffect(user) {
        user?.let {
            userEmail.value = it.email ?: "No Email"
            userPhotoUrl.value = it.photoUrl?.toString()

            // Get full name from Firestore
            db.collection("users").document(it.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val firstName = document.getString("name") ?: "No Name"
                        val surname = document.getString("surname") ?: ""
                        userName.value = "$firstName $surname"
                    } else {
                        userName.value = "No Name Found"
                    }
                }
                .addOnFailureListener {
                    userName.value = "Error Loading Name"
                }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        },
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                userPhotoUrl.value?.let { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = "Profile Picture",
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                    )
                } ?: Icon(Icons.Default.AccountCircle, contentDescription = "Default Profile", modifier = Modifier.size(100.dp))

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Name: ${userName.value}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(text = "Email: ${userEmail.value}", fontSize = 16.sp)

                Spacer(modifier = Modifier.height(20.dp))

                Button(onClick = { FirebaseAuth.getInstance().signOut(); navController.navigate("login") }) {
                    Text("Logout")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OtherScreen() { // ✅ Pass navController
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        },

    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            Text("Other Screen", fontSize = 24.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskScreen(navController: NavController, viewModel: TaskViewModel) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Low") }
    var category by remember { mutableStateOf("General") }
    val dueDate by remember { mutableLongStateOf(System.currentTimeMillis()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Task") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Task Description") }, modifier = Modifier.fillMaxWidth())

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Low", "Medium", "High").forEach { p ->
                    RadioButton(selected = priority == p, onClick = { priority = p })
                    Text(text = p, modifier = Modifier.align(Alignment.CenterVertically))
                }
            }

            DropdownMenuComponent(selectedCategory = category, onCategorySelected = { category = it })

            Button(
                onClick = {
                    val newTask = Task(title = title, description = description, priority = priority, category = category, dueDate = dueDate)
                    viewModel.addTask(newTask)
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Task")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTaskScreen(navController: NavController, viewModel: TaskViewModel, taskId: Int) {
    val task = viewModel.getTaskById(taskId).collectAsState(initial = null).value
    var title by remember { mutableStateOf(task?.title ?: "") }
    var description by remember { mutableStateOf(task?.description ?: "") }
    var priority by remember { mutableStateOf(task?.priority ?: "Low") }
    var category by remember { mutableStateOf(task?.category ?: "General") }
    var dueDate by remember { mutableLongStateOf(task?.dueDate ?: System.currentTimeMillis()) }

    // Update UI fields when task is fetched
    LaunchedEffect(task) {
        task?.let {
            title = it.title
            description = it.description
            priority = it.priority
            category = it.category
            dueDate = it.dueDate!!
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Task") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.deleteTask(task!!)
                            navController.popBackStack()
                        }
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Task", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Task Description") }, modifier = Modifier.fillMaxWidth())

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Low", "Medium", "High").forEach { p ->
                    RadioButton(selected = priority == p, onClick = { priority = p })
                    Text(text = p, modifier = Modifier.align(Alignment.CenterVertically))
                }
            }

            DropdownMenuComponent(selectedCategory = category, onCategorySelected = { category = it })

            Button(
                onClick = {
                    val updatedTask = Task(id = task!!.id, title = title, description = description, priority = priority, category = category, dueDate = dueDate)
                    viewModel.updateTask(updatedTask)
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Changes")
            }
        }
    }
}

@Composable
fun DropdownMenuComponent(selectedCategory: String, onCategorySelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val categories = listOf("Work", "Personal", "Shopping", "Health", "Other")

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(selectedCategory)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            categories.forEach { category ->
                DropdownMenuItem(
                    text = { Text(category) },
                    onClick = {
                        onCategorySelected(category)  // Update selected category
                        expanded = false  // Close menu
                    }
                )
            }
        }
    }
}

@Composable
fun TaskPieChart(taskStats: Map<String, Int>) {
    val colors = listOf(Color.Green, Color.Red) // Green for Completed, Red for Pending
    val totalTasks = taskStats.values.sum()

    if (totalTasks == 0) {
        Text("No tasks available", modifier = Modifier.padding(16.dp))
        return
    }

    val sweepAngles = taskStats.values.map { (it.toFloat() / totalTasks) * 360f }

    Canvas(modifier = Modifier.size(200.dp)) {
        var startAngle = 0f
        taskStats.keys.forEachIndexed { index, key ->
            drawArc(
                color = colors[index % colors.size],
                startAngle = startAngle,
                sweepAngle = sweepAngles[index],
                useCenter = true,
                topLeft = Offset(0f, 0f),
                size = Size(size.width, size.height)
            )
            startAngle += sweepAngles[index]
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Column {
        taskStats.keys.forEachIndexed { index, key ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(colors[index % colors.size])
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "$key: ${taskStats[key]}")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: TaskViewModel) {
    val taskStats by viewModel.taskStats.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TaskMate", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorResource(id = R.color.blue),
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->  // ✅ Added paddingValues
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues), // ✅ Apply padding inside Scaffold
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Task Completion", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            // 🔥 Call TaskPieChart and pass task statistics
            TaskPieChart(taskStats)
        }
    }
}


@Composable
fun TaskItem(task: Task, onTaskClick: () -> Unit, onTaskCompleted: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onTaskClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onTaskCompleted() }
            )

            Column(modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)) {
                Text(task.title, style = MaterialTheme.typography.bodyLarge)
                Text(task.category, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }

            Text(
                text = task.priority,
                color = when (task.priority) {
                    "High" -> Color.Red
                    "Medium" -> Color.Yellow
                    else -> Color.Green
                },
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Preview(showBackground = true)
@Composable
fun TaskScreenPreview() {
    val sampleTasks = listOf(
        Task(id = 1, title = "Buy Groceries", description = "Milk, Bread, Eggs", priority = "High", category = "Shopping", isCompleted = false),
        Task(id = 2, title = "Workout", description = "Morning Exercise", priority = "Medium", category = "Health", isCompleted = true)
    )

    TaskMateTheme {
        Scaffold {
            LazyColumn {
                items(sampleTasks) { task ->
                    TaskItem(task = task, onTaskClick = {}, onTaskCompleted = {})
                }
            }
        }
    }
}

