package com.example.taskmate

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskViewModel(private val repository: TaskRepository) : ViewModel() {

    private val _filterStatus = MutableStateFlow("All")
    private val _sortOption = MutableStateFlow("Due Date")

    val filterStatus: StateFlow<String> = _filterStatus
    val sortOption: StateFlow<String> = _sortOption

    // ✅ Fetch all tasks with filtering & sorting
    val allTasks: StateFlow<List<Task>> = repository.allTasks
        .combine(_filterStatus) { tasks, filter ->
            when (filter) {
                "Completed" -> tasks.filter { it.isCompleted }
                "Pending" -> tasks.filter { !it.isCompleted }
                else -> tasks
            }
        }
        .combine(_sortOption) { tasks, sort ->
            when (sort) {
                "Name" -> tasks.sortedBy { it.title.lowercase() }
                "Due Date" -> tasks.sortedBy { it.dueDate }
                else -> tasks
            }
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ✅ Compute Task Statistics: Completed vs Pending Tasks
    val taskStats: StateFlow<Map<String, Int>> = allTasks.map { tasks ->
        val completed = tasks.count { it.isCompleted }
        val pending = tasks.count { !it.isCompleted }
        mapOf("Completed" to completed, "Pending" to pending)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyMap())

    // ✅ Function to ADD a Task
    fun addTask(task: Task) = viewModelScope.launch {
        repository.insertTask(task)
    }

    // ✅ Function to UPDATE a Task
    fun updateTask(task: Task) = viewModelScope.launch {
        repository.updateTask(task)
    }

    // ✅ Function to DELETE a Task
    fun deleteTask(task: Task) = viewModelScope.launch {
        repository.deleteTask(task)
    }

    // ✅ Function to GET a Task by ID
    fun getTaskById(taskId: Int): StateFlow<Task?> {
        return repository.getTaskById(taskId)
            .stateIn(viewModelScope, SharingStarted.Lazily, null)
    }

    // ✅ Function to SET Filtering Status
    fun setFilterStatus(status: String) {
        _filterStatus.value = status
    }

    // ✅ Function to SET Sorting Option
    fun setSortOption(option: String) {
        _sortOption.value = option
    }
}

/*class TaskViewModel(private val repository: TaskRepository) : ViewModel() {

    // Use MutableLiveData to hold the list of tasks
    private val _allTasks = MutableLiveData<List<Task>>()
    val allTasks: LiveData<List<Task>> get() = _allTasks // Exposed as immutable LiveData

    init {
        fetchTasks() // Load tasks initially
    }

    private fun fetchTasks() {
        viewModelScope.launch {
            repository.allTasks.collect { tasks ->
                _allTasks.postValue(tasks) // Collects Flow and updates LiveData
            }
        }
    }

    fun addTask(task: Task) = viewModelScope.launch { repository.insertTask(task) }
    fun updateTask(task: Task) = viewModelScope.launch { repository.updateTask(task) }
    fun deleteTask(task: Task) = viewModelScope.launch { repository.deleteTask(task) }

    // Convert Flow to LiveData for getting a task by ID
    fun getTaskById(taskId: Int): LiveData<Task?> = repository.getTaskById(taskId).asLiveData()
}*/
