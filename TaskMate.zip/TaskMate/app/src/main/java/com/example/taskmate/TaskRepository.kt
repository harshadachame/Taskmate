package com.example.taskmate

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class TaskRepository(private val dao: TaskDao) {
    private val db = FirebaseFirestore.getInstance()
    private val user = FirebaseAuth.getInstance().currentUser

    val allTasks: Flow<List<Task>> = dao.getAllTasks()

    suspend fun insertTask(task: Task) {
        dao.insertTask(task)
        uploadTaskToFirestore(task) // Sync to Firestore
    }

    suspend fun updateTask(task: Task) {
        dao.updateTask(task)
        uploadTaskToFirestore(task) // Update Firestore
    }

    suspend fun deleteTask(task: Task) {
        dao.deleteTask(task)
        deleteTaskFromFirestore(task.id) //  Delete from Firestore
    }

    fun getTaskById(taskId: Int): Flow<Task?> {
        return dao.getTaskById(taskId)
    }

    private fun uploadTaskToFirestore(task: Task) {
        user?.let {
            db.collection("users").document(it.uid).collection("tasks")
                .document(task.id.toString()) // Use task ID as Firestore document ID
                .set(task)
        }
    }

    private fun deleteTaskFromFirestore(taskId: Int) {
        user?.let {
            db.collection("users").document(it.uid).collection("tasks")
                .document(taskId.toString())
                .delete()
        }
    }

    // Fetch tasks from Firestore and store in Room
    fun syncTasksFromFirestore() {
        user?.let { u ->
            db.collection("users").document(u.uid).collection("tasks")
                .get()
                .addOnSuccessListener { snapshot ->
                    val taskList = snapshot.documents.mapNotNull { it.toObject(Task::class.java) }

                    // Replace Room data with Firestore data
                    CoroutineScope(Dispatchers.IO).launch {
                        dao.clearAll()
                        dao.insertTasks(taskList)
                    }
                }
        }
    }
}
